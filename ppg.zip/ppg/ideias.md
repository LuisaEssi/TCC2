## .ipybn -> .py
`jupyter-nbconvert --to python ppg.ipynb`